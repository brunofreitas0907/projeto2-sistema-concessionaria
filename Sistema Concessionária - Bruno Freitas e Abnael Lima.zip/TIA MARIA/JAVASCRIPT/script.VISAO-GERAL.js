const buttonSair = document.querySelector('.sairConta').addEventListener('click' , () => {
    localStorage.removeItem('currentEmail');
    window.location.href ='../HTML/index.LOGIN.html';
});

if (!localStorage.getItem('currentEmail')) {
    window.location.href = '../HTML/index.LOGIN.html'; 
};

document.addEventListener('DOMContentLoaded', function() {
    const visaoGeral = document.querySelector('.visao-geral');
    const formularioCadastro = document.querySelector('.container');
    const vendasVeiculos = document.getElementById('vendasVeiculos'); 
    const dashboardLink = document.getElementById('dashboard');
    const cadastrarCliente = document.getElementById('cadastrarCliente');
    const vendas = document.getElementById('vendas');
    const informacoesVendas = document.querySelector('.informacoes-vendas');
    const infoVendasMenu = document.getElementById('informacoes-vendas');
    const cadastroVeiculos = document.getElementById('mostrarVeiculos');
    const veiculos = document.getElementById('veiculos');
    const opcaoTrocarContas = document.getElementById('trocar-contas');
    const vendasCompleto = document.querySelector('.vendas-completo');
    const trocarConta = document.querySelector('.trocarConta');
    const mostrarPesquisaGeral = document.getElementById('pesquisaGeral');
    const botaoGeralpesquisa =document.getElementById('pesquisaGeralBotao');
    const ressultadoPesquisaGeral = document.getElementById('resultadoPesquisaGeral');
    const buttonMudarSenha = document.getElementById('mudarSenha');
    const verificarSenha = document.querySelector('.verificarSenhaAtual');
    const alterarSenha = document.querySelector('.alterarSenhaAtual');
    
    function hideAllSections() {
        visaoGeral.setAttribute('hidden' , '');
        visaoGeral.style.display = 'none';
        formularioCadastro.setAttribute('hidden' , '');
        formularioCadastro.style.display = 'none';
        vendasVeiculos.setAttribute('hidden' , '');
        vendasVeiculos.style.display = 'none';
        informacoesVendas.setAttribute('hidden' , '');
        informacoesVendas.style.display = 'none';
        cadastroVeiculos.setAttribute('hidden', '');
        cadastroVeiculos.style.display = 'none';
        vendasCompleto.style.display = 'none';
        trocarConta.setAttribute('hidden' , '');
        trocarConta.style.display = 'none';
        mostrarPesquisaGeral.setAttribute('hidden', '');
        mostrarPesquisaGeral.style.display = '';
        ressultadoPesquisaGeral.removeAttribute('hidden', '');
        verificarSenha.setAttribute('hidden' , '');
        verificarSenha.style.display = 'none';
        alterarSenha.setAttribute('hidden' , '');
        alterarSenha.style.display = 'none';
    }
    
    if (dashboardLink && visaoGeral && formularioCadastro) {

        dashboardLink.addEventListener('click', function(event) {
            window.location.reload();
            event.preventDefault(); 
            hideAllSections();
            visaoGeral.removeAttribute('hidden');
            visaoGeral.style.display = 'flex';
            
            abrirPesquisa.style.display = "none"
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
        });

    } else {
        console.error('Elemento dashboardLink, visaoGeral ou formularioCadastro não encontrado.');
    }

    if (formularioCadastro && cadastrarCliente && visaoGeral) {

        cadastrarCliente.addEventListener('click', function(event) {
            event.preventDefault();
            hideAllSections();
            formularioCadastro.style.display = 'flex';
            formularioCadastro.removeAttribute('hidden');

            abrirPesquisa.style.display = "none"
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
            
        });

    } else {
        console.error('Elemento #cadastrarCliente ou .mostrarCadastro não encontrado.');
    }

    if (vendasVeiculos && vendas) {
        vendas.addEventListener('click', function(event) {
            event.preventDefault();
            hideAllSections();
            vendasVeiculos.removeAttribute('hidden');
            vendasVeiculos.style.display = 'flex';
            
            vendasVeiculos.classList.remove('ocultar');
            abrirPesquisa.style.display = 'none';
            vendasCompleto.style.display = 'flex';
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
        });
    } else {
        console.error('Elemento #vendas ou .vendasVeiculos não encontrado.');
    }

    if(informacoesVendas && infoVendasMenu) {
        infoVendasMenu.addEventListener('click' , function(event) {
            event.preventDefault();
            hideAllSections();
            informacoesVendas.removeAttribute('hidden');
            informacoesVendas.style.display = 'flex';
            
            abrirPesquisa.style.display = "none"
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
        })
    } else {
        console.error('Elemento informacoesVendas ou inforVendasMenu não encontrado');
    }

    if(cadastroVeiculos && veiculos ) {
        veiculos.addEventListener('click' , function(event) {
            event.preventDefault();
            hideAllSections();
            cadastroVeiculos.removeAttribute('hidden');
            cadastroVeiculos.style.display = 'flex';

            abrirPesquisa.style.display = "none"
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
        })
    } else {
        console.error('Elemento informacoesVendas ou inforVendasMenu não encontrado');
    }

    if(mostrarPesquisaGeral && botaoGeralpesquisa){
        botaoGeralpesquisa.addEventListener('click', function(event){
            event.preventDefault();
            hideAllSections();
            mostrarPesquisaGeral.removeAttribute('hidden');
        });
    }

    if(trocarConta) {
        opcaoTrocarContas.addEventListener('click' , function(event) {
            event.preventDefault();
            hideAllSections();

            trocarConta.removeAttribute('hidden');
            trocarConta.style.display = 'flex';
            mostrarPesquisaGeral.style.display = 'none';
            ressultadoPesquisaGeral.setAttribute('hidden', '');
            mostrarPesquisaGeral.style.display = 'none';
        })
    }

    if(verificarSenha) {
        buttonMudarSenha.addEventListener('click' , () => {
            hideAllSections();
            verificarSenha.removeAttribute('hidden');
            verificarSenha.style.display = 'flex';
            mostrarPesquisaGeral.style.display = 'none';

            const buttonVerificar = document.getElementById('verificar');
            let erroSenha = document.querySelector('.erroSenha');

            buttonVerificar.onclick = function() {
                let senhaAtual = document.getElementById('senhaAtual').value;
                let senhaStorage = localStorage.getItem('senhaAtual') || '';

                if(senhaAtual === '') {
                    erroSenha.textContent = 'VOCÊ PRECISA INSERIR UM VALOR.'
                } else if(senhaAtual === senhaStorage) {
                    hideAllSections();
                    alterarSenha.removeAttribute('hidden');
                    alterarSenha.style.display = 'flex';
                    erroSenha.textContent = '';
                    senhaAtual.value = '';
                } else {
                    erroSenha.textContent = 'SENHA ERRADA.'
                }
            }

            const buttonConfirm = document.querySelector('.alterarSenha');

            buttonConfirm.onclick = function() {
                let erroSenhaNew = document.querySelector('.erroSenhaNew');
                let novaSenha = document.getElementById('novaSenha').value;
                let novaSenhaConfirm = document.getElementById('novaSenhaConfirm').value;
                let senhaStorage = localStorage.getItem('senhaAtual') || '';
                erroSenhaNew.textContent = '';

                if(novaSenha === '' && novaSenhaConfirm === '') {
                    erroSenhaNew.textContent = 'VOCÊ PRECISA INSERIR OS VALORES.'
                } else if (novaSenha === '') {
                    erroSenhaNew.textContent = 'VOCÊ PRECISA DEFINIR A NOVA SENHA.'
                } else if(novaSenhaConfirm === '') {
                    erroSenhaNew.textContent = 'VOCÊ PRECISA CONFIRMAR A SENHA.'
                } else if(novaSenha === senhaStorage) {
                    erroSenhaNew.textContent = 'A SENHA DEVE SER DIFERENTE DA ANTIGA.'
                } else if(novaSenha === novaSenhaConfirm) {
                    hideAllSections();
                    localStorage.setItem('senhaAtual' , novaSenha);
                    novaSenha.value = '';
                    novaSenhaConfirm.value = '';
                    const sucessoSenha = document.querySelector('.sucessoSenha');
                    sucessoSenha.removeAttribute('hidden');
                    
                    const buttonSucessoSenha = document.querySelector('.buttonSucessoSenha');
                    buttonSucessoSenha.onclick = function() {
                        window.location.reload();
                        sucessoSenha.setAttribute('hidden' , '');
                    }


                } else {
                    erroSenhaNew.textContent = 'AS SENHAS NÃO CONFEREM.';
                }
            }
        })
    }
});

// SOMA O TOTAL DE VENDAS PRA INSERIR N0 DASHBOARD

// 7 DIAS
document.addEventListener('DOMContentLoaded', function() {
    let vendas = JSON.parse(localStorage.getItem('vendas')) || [];
    const vendas7dias = document.querySelector('.ultimos-7dias .preco');
    const quantidadeVendas7d = document.querySelector('.quantidade-7d .quantidade');
    
    let quantidadeVendas = vendas.length;
    quantidadeVendas7d.textContent = quantidadeVendas;

    const hoje = new Date();
    const seteDiasAtras = new Date(hoje);
    seteDiasAtras.setDate(hoje.getDate() - 7);

    const vendasRecentes = vendas.filter(venda => {
        const dataParts = venda.data.match(/(\d{2})\/(\d{2})\/(\d{4}), (\d{2}:\d{2}:\d{2})/);
        const dataVenda = new Date(`${dataParts[3]}-${dataParts[2]}-${dataParts[1]} ${dataParts[4]}`);
        return dataVenda >= seteDiasAtras && dataVenda <= hoje;
    });

    function toConvertToBrasilian(valor) {
        if(typeof valor !== 'string') return parseFloat(valor) || 0;
        
        let cleanedValue = valor.replace(/R\$\s?/g, '').trim();
        
        if(cleanedValue.includes(',')) {
            const parts = cleanedValue.split(',');
            const parteInteira = parts[0].replace(/\./g, '');
            const parteDecimal = parts[1] || '00';
            return parseFloat(parteInteira + '.' + parteDecimal);
        }
        
        if(cleanedValue.includes('.')) {
            const parts = cleanedValue.split('.');
            if(parts.length >= 3) {
                const centavos = parts.pop();
                const parteInteira = parts.join('');
                return parseFloat(parteInteira + '.' + centavos);
            }
        }
        
        return parseFloat(cleanedValue) || 0;
    }


    const totalVendas = vendasRecentes.reduce((total, venda) => total + toConvertToBrasilian(venda.valor), 0);
    
    vendas7dias.textContent = totalVendas.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
});

// 30 DIAS
document.addEventListener('DOMContentLoaded', function() {
    let vendas = JSON.parse(localStorage.getItem('vendas')) || [];
    const vendas30dias = document.querySelector('.ultimos-30dias .preco');
    const quantidadeVendas30d = document.querySelector('.quantidade-30d .quantidade');

    quantidadeVendas30d.textContent = vendas.length;

    const hoje = new Date();
    const seteDiasAtras = new Date(hoje);
    seteDiasAtras.setDate(hoje.getDate() - 30);

    const vendasRecentes = vendas.filter(venda => {
        const dataParts = venda.data.match(/(\d{2})\/(\d{2})\/(\d{4}), (\d{2}:\d{2}:\d{2})/);
        const dataVenda = new Date(`${dataParts[3]}-${dataParts[2]}-${dataParts[1]} ${dataParts[4]}`);
        return dataVenda >= seteDiasAtras && dataVenda <= hoje;
    });

    function toConvertToBrasilian(valor) {
        if(typeof valor !== 'string') return parseFloat(valor) || 0;

        let cleanedValue = valor.replace(/R\$\s?/g, '').trim();

        if(cleanedValue.includes(',')) {
            const part = cleanedValue.split(',');
            const parteInteira = parts[0].replace(/\./g, '');
            const parteDecimal = parts[1] || '00';
            return parseFloat(parteInteira + '.' + parteDecimal);
        }

        if(cleanedValue.includes('.')) {
            const parts = cleanedValue.split('.');
            if(parts.length >= 3) {
                const centavos = parts.pop();
                const parseInteira = parts.join('');
                return parseFloat(parseInteira + '.' + centavos);
            }
        }

        return parseFloat(cleanedValue) || 0;
    }

    const totalVendas = vendasRecentes.reduce((total, venda) => total + toConvertToBrasilian(venda.valor), 0);
    vendas30dias.textContent = totalVendas.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
});

