const abrirPesquisa = document.getElementById("abrirPesquisa");
const cadastroVeiculos = document.getElementById("mostrarVeiculos");
const veiculos = document.getElementById("veiculos");

function formatarValor(valor) {
  const valorNumerico = parseFloat(valor);
  if (isNaN(valorNumerico)) return "R$ 0,00";
  const partes = valorNumerico.toFixed(2).split(".");
  let inteiro = partes[0].replace(/\B(?=(\d{3})+(?!\d))/g, ".");
  return `R$ ${inteiro},${partes[1]}`;
}

function validarPlaca(input) {
  let value = input.value.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
  if (value.length > 7) value = value.slice(0, 7);
  let formattedValue = "";

  for (let i = 0; i < value.length; i++) {
    if (i < 3 || i === 4) {
      if (/[A-Za-z]/.test(value[i])) formattedValue += value[i];
      else {
        value = value.slice(0, i);
        break;
      }
    } else if (i === 3 || i === 5 || i === 6) {
      if (/[0-9]/.test(value[i])) formattedValue += value[i];
      else {
        value = value.slice(0, i);
        break;
      }
    }
  }

  input.value = formattedValue;
}

function validarValor(input) {
  let value = input.value.replace(/\D/g, "");
  if (value.length > 12) value = value.slice(0, 12);

  const valorNumerico = parseFloat(value) / 100;
  if (isNaN(valorNumerico)) {
    input.value = "";
    return;
  }

  input.value = formatarValor(valorNumerico);
}

document.getElementById("placa").addEventListener("input", function (event) {
  validarPlaca(event.target);
});

document.getElementById("valor").addEventListener("input", function (event) {
  validarValor(event.target);
});

const placaPesquisa = document.getElementById("placaPesquisa");
if (placaPesquisa) {
  placaPesquisa.addEventListener("input", function (event) {
    validarPlaca(event.target);
  });
}

function salvar(event) {
  event.preventDefault();
  const renavam = document.getElementById("renavamVeiculo").value.trim();
  const placa = document.getElementById("placa").value.trim();
  const marcaModelo = document.getElementById("marcaModelo").value.trim();
  const cor = document.getElementById("cor").value.trim();
  const ano = document.getElementById("ano").value.trim();
  const modelo = document.getElementById("modelo").value.trim();
  const categoria = document.getElementById("categoria").value.trim();
  const combustivel = document.getElementById("combustivel").value;
  const valorInput = document.getElementById("valor").value.trim();

  if (
    !renavam ||
    !placa ||
    !marcaModelo ||
    !cor ||
    !ano ||
    !modelo ||
    !categoria ||
    !combustivel ||
    !valorInput
  ) {
    alert("Por favor, preencha todos os campos obrigatórios.");
    return;
  }

  const valor =
    parseFloat(valorInput.replace(/[^\d,]/g, "").replace(",", ".")) || 0;
  if (isNaN(valor)) {
    alert("Por favor, insira um valor numérico válido.");
    return;
  }

  const veiculo = {
    renavam,
    placa,
    marcaModelo,
    cor,
    ano,
    modelo,
    categoria,
    combustivel,
    valor,
  };

  let veiculosList = JSON.parse(localStorage.getItem("veiculos")) || [];
  veiculosList.push(veiculo);

  try {
    localStorage.setItem("veiculos", JSON.stringify(veiculosList));
    alert("Veículo salvo com sucesso!");
    document.getElementById("formVeiculo").reset();
  } catch (e) {
    console.error("Erro ao salvar no LocalStorage:", e);
    alert(
      "Erro ao salvar os dados. Verifique se o armazenamento do navegador está habilitado."
    );
  }
}

function excluir() {
  alert("Função Excluir não implementada. Selecione um veículo para excluir.");
}

function cancelar() {
  document.getElementById("formVeiculo").reset();
  alert("Operação cancelada.");
}

function procurar() {
  abrirPesquisa.style.display = "flex";
  cadastroVeiculos.style.display = "none";
}

function sair() {
  if (confirm("Deseja realmente sair?")) {
    window.close();
  }
}

veiculos.addEventListener("click", function (event) {
  event.preventDefault();
  cadastroVeiculos.hidden = !cadastroVeiculos.hidden;
});

function pesquisar(event) {
  event.preventDefault();

  const renavam = document.getElementById("renavamPesquisa")?.value.trim();
  const placa = document.getElementById("placaPesquisa")?.value.trim();

  if (!renavam && !placa) {
    alert("Por favor, preencha pelo menos um dos campos: Renavam ou Placa.");
    return;
  }

  let veiculos = JSON.parse(localStorage.getItem("veiculos")) || [];

  const resultados = veiculos.filter((veiculo) => {
    const matchRenavam = renavam ? veiculo.renavam === renavam : false;
    const matchPlaca = placa ? veiculo.placa === placa : false;
    return matchRenavam || matchPlaca;
  });

  const resultadosDiv = document.getElementById("resultados");
  if (resultados.length === 0) {
    resultadosDiv.innerHTML =
      '<p class="no-results">Nenhum veículo encontrado.</p>';
    return;
  }

  let tabela = `
        <table>
            <thead>
                <tr>
                    <th>Renavam</th>
                    <th>Placa</th>
                    <th>Marca</th>
                    <th>Cor</th>
                    <th>Ano</th>
                    <th>Modelo</th>
                    <th>Categoria</th>
                    <th>Combustível</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
    `;
  resultados.forEach((veiculo) => {
    tabela += `
            <tr>
                <td>${veiculo.renavam}</td>
                <td>${veiculo.placa}</td>
                <td>${veiculo.marcaModelo}</td>
                <td>${veiculo.cor}</td>
                <td>${veiculo.ano}</td>
                <td>${veiculo.modelo}</td>
                <td>${veiculo.categoria}</td>
                <td>${veiculo.combustivel}</td>
                <td>${formatarValor(veiculo.valor)}</td>
            </tr>
        `;
  });
  tabela += "</tbody></table>";
  resultadosDiv.innerHTML = tabela;
}
