document
  .getElementById("formularioVenda")
  .addEventListener("submit", function (event) {
    event.preventDefault();

    const formData = new FormData(event.target);

    const valorInput = formData.get("valor-pagamento");
    const cleanValor = valorInput.replace(/R\$|\s/g, "").replace(",", ".");

    const data = new Date().toLocaleString("pt-BR", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });

    const venda = {
      cpf: formData.get("cpf-venda"),
      renavam: formData.get("renavam"),
      pagamento: formData.get("forma-pagamento"),
      valor: cleanValor,
      data: data,
    };

    let vendas = JSON.parse(localStorage.getItem("vendas")) || [];

    vendas.push(venda);

    localStorage.setItem("vendas", JSON.stringify(vendas));

    event.target.reset();

    const formVendasCompleto = document.getElementById('formularioVenda');
    formVendasCompleto.setAttribute('hidden' , '');
    const sucessoVenda = document.querySelector('.sucessoVenda');
    sucessoVenda.removeAttribute('hidden');
  });

const buttonSucesso = document.querySelector('.sucesso').addEventListener('click' , function(event) {
  const sucessoVenda = document.querySelector('.sucessoVenda');
  sucessoVenda.setAttribute('hidden' , '');
  window.location.reload();
});

document.addEventListener("DOMContentLoaded", function () {
  function atualizarTabelaVendas() {
    const venda = JSON.parse(localStorage.getItem("vendas")) || [];
    const corpoTabela = document.getElementById("corpo-tabela");
    const valorTotalVendas = document.getElementById('total-vendas');

    valorTotalVendas.textContent = venda.length;

    corpoTabela.innerHTML = venda
      .map(
        (dado, index) => `
            <tr>
                <td>${dado.cpf}</td>
                <td>${dado.renavam}</td>
                <td>${dado.data}</td>
                <td>${dado.pagamento}</td>
                <td>${dado.valor}</td>
                <td><button onclick='deletarVenda(${index})'>X</button></td>
            </tr>
        `
      )
      .join("");

    window.deletarVenda = function (index) {
      let vendas = JSON.parse(localStorage.getItem("vendas")) || [];
      vendas.splice(index, 1);
      localStorage.setItem("vendas", JSON.stringify(vendas));
      atualizarTabelaVendas();
    };
  }

  atualizarTabelaVendas();
});

// FORMATA CAMPOS DE INPUT PARA FORMATO PADRÃO EM TEMPO REAL
document
  .getElementById("cpf-venda")
  .addEventListener("input", function (event) {
    let value = event.target.value.replace(/\D/g, ""); 
    if (value.length > 11) value = value.slice(0, 11); 
    else if (value.length > 9)
      value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    else if (value.length > 6)
      value = value.replace(/(\d{3})(\d{3})(\d{3})/, "$1.$2.$3-");
    else if (value.length > 3)
      value = value.replace(/(\d{3})(\d{3})/, "$1.$2.");
    else if (value.length > 1) value = value.replace(/(\d{3})/, "$1.");
    else value = value;

    event.target.value = value;
  });

document
  .getElementById("cpf-cadastro")
  .addEventListener("input", function (event) {
    let value = event.target.value.replace(/\D/g, ""); 
    if (value.length > 11) value = value.slice(0, 11); 
    else if (value.length > 9)
      value = value.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, "$1.$2.$3-$4");
    else if (value.length > 6)
      value = value.replace(/(\d{3})(\d{3})(\d{3})/, "$1.$2.$3-");
    else if (value.length > 3)
      value = value.replace(/(\d{3})(\d{3})/, "$1.$2.");
    else if (value.length > 1) value = value.replace(/(\d{3})/, "$1.");
    else value = value;

    event.target.value = value;
  });

document.getElementById("telefone").addEventListener("input", function (event) {
  let value = event.target.value.replace(/\D/g, "");
  if (value.length > 11) value = value.slice(0, 11);
  else if (value.length > 4)
    value = value.replace(/(\d{2})(\d{5})/, "($1) $2-");
  else if (value.length > 1) value = value.replace(/(\d{2})/, "($1) ");
  else if (value.length === 1) value = value.replace(/(\d{1})/, "($1");

  event.target.value = value;
});

document.getElementById("cep").addEventListener("input", function (event) {
  let value = event.target.value.replace(/\D/g, "");
  if (value.length > 9) value = value.slice(0, 9);
  else if (value.length > 4) value = value.replace(/(\d{5})/, "$1-");

  event.target.value = value;
});

document.getElementById("placa").addEventListener("input", function (event) {
  let value = event.target.value.replace(/[^A-Za-z0-9]/g, "").toUpperCase();
  if (value.length > 7) value = value.slice(0, 7);
  let formattedValue = "";

  for (let i = 0; i < value.length; i++) {
    if (i < 3 || i === 4) {
      if (/[A-Za-z]/.test(value[i])) formattedValue += value[i];
      else {
        value = value.slice(0, i);
        break;
      }
    } else if (i === 3 || i === 5 || i === 6) {
      if (/[0-9]/.test(value[i])) formattedValue += value[i];
      else {
        value = value.slice(0, i);
        break;
      }
    }
  }

  event.target.value = formattedValue;
});

document
  .getElementById("valor-pagamento")
  .addEventListener("input", function (event) {
    let value = event.target.value.replace(/\D/g, "");

    if (value.length > 9) value = value.slice(0, 12);

    let formatted = "";
    if (value.length > 0) {
      let cents = value.slice(-2);
      let integer = value.slice(0, -2);

      if (integer) {
        let reversed = integer.split("").reverse().join("");
        reversed = reversed.replace(/(\d{3})(?=\d)/g, "$1.");
        integer = reversed.split("").reverse().join("");
        formatted = `R$ ${integer},${cents}`;
      } else {
        formatted = `R$ ${cents}`;
      }
    }

    event.target.value = formatted;
  });
