function mostrarTop5Carros() {
    const divTopCarros = document.getElementById('top-carros');
    if (!divTopCarros) return; 
  
    const vendas = JSON.parse(localStorage.getItem('vendas') || '[]');
    const veiculos = JSON.parse(localStorage.getItem('veiculos') || '[]');
  

    const contagem = {};
    vendas.forEach(venda => {
      const renavam = venda.renavam;
      const veiculo = veiculos.find(v => v.renavam === renavam);
      if (veiculo) {
        const chave = `${veiculo.marcaModelo}|${renavam}`; 
        if (!contagem[chave]) {
          contagem[chave] = {
            marcaModelo: veiculo.marcaModelo,
            renavam: renavam,
            valor: veiculo.valor, 
            count: 0
          };
        }
        contagem[chave].count++;
      }
    });

    const topCarros = Object.values(contagem)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  
    const lista = document.createElement('ul');
    if (topCarros.length === 0) {
      const item = document.createElement('li');
      item.textContent = 'Nenhuma venda registrada.';
      lista.appendChild(item);
    } else {
      topCarros.forEach(carro => {
        const item = document.createElement('li');
        item.textContent = `${carro.marcaModelo} - ${carro.renavam} - R$ ${carro.valor.toFixed(2)}`;
        lista.appendChild(item);
        item.style.color = 'white';
        item.style.textAlign = 'left';
        item.style.fontWeight = '450';
      });
    }
  
    divTopCarros.innerHTML = '';
    divTopCarros.appendChild(lista);
  }
  
  window.addEventListener('DOMContentLoaded', mostrarTop5Carros);
  
  document.getElementById('formularioVenda')?.addEventListener('submit', function () {
    setTimeout(mostrarTop5Carros, 0);
  });