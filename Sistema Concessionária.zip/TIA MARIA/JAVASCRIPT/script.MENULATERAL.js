var menuItem = document.querySelectorAll('.item-menu' , 'logo-empresa');

function selecionarLink(){
    menuItem.forEach((item) =>{
        item.classList.remove('ativo');
    });
    this.classList.add('ativo');
}

menuItem.forEach((item) =>{
    item.addEventListener('click', selecionarLink);
});
