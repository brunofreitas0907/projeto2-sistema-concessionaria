const formulario = document.querySelector('.bloco-login');
const mensagemErro = document.querySelector('.mensagem-erro');
const emailOficial = 'acessorestrito@gmail.com';
const senhaOficial = '2025';
localStorage.setItem('emailAtual' , emailOficial);
localStorage.setItem('senhaAtual' , senhaOficial);

formulario.addEventListener('submit' , function(event) {
    event.preventDefault();

    const email = document.querySelector('.caixa-email').value;
    const senha = document.querySelector('.caixa-senha').value;
    
    if(email === emailOficial && senha === senhaOficial) {

        const emailArray = [{email: email}];
        email.value = '';
        senha.value = '';
        localStorage.setItem('currentEmail' , JSON.stringify(emailArray));
        window.location.href = '../HTML/index.VISAO-GERAL.html';
        
    } else if (email === emailOficial && senha != senhaOficial) {
        mensagemErro.textContent = 'Senha Incorreta.';
    } else if (email != emailOficial && senha === senhaOficial) {
        mensagemErro.textContent = 'Email Incorreto.';
    } else {
        mensagemErro.textContent = 'Email e senha incorretos.';
    }
});

(function () {
    window.history.pushState(null, null, window.location.href);
    window.onpopstate = function () {
      window.history.pushState(null, null, window.location.href);
    };
  })();