function mostrarTop5Carros() {
    const divTopCarros = document.getElementById('top-carros');
    if (!divTopCarros) return; // Exit if div not found
  
    // Get sales and vehicles from localStorage
    const vendas = JSON.parse(localStorage.getItem('vendas') || '[]');
    const veiculos = JSON.parse(localStorage.getItem('veiculos') || '[]');
  
    // Count sales by RENAVAM
    const contagem = {};
    vendas.forEach(venda => {
      const renavam = venda.renavam;
      const veiculo = veiculos.find(v => v.renavam === renavam);
      if (veiculo) {
        const chave = `${veiculo.marcaModelo}|${renavam}`; // Unique key
        if (!contagem[chave]) {
          contagem[chave] = {
            marcaModelo: veiculo.marcaModelo,
            renavam: renavam,
            valor: veiculo.valor, // Use valor from veiculos
            count: 0
          };
        }
        contagem[chave].count++;
      }
    });
  
    // Convert to array, sort by count (descending), take top 5
    const topCarros = Object.values(contagem)
      .sort((a, b) => b.count - a.count)
      .slice(0, 5);
  
    // Create HTML list
    const lista = document.createElement('ul');
    if (topCarros.length === 0) {
      const item = document.createElement('li');
      item.textContent = 'Nenhuma venda registrada.';
      lista.appendChild(item);
    } else {
      topCarros.forEach(carro => {
        const item = document.createElement('li');
        item.textContent = `${carro.marcaModelo} - ${carro.renavam} - R$ ${carro.valor.toFixed(2)}`;
        lista.appendChild(item);
        item.style.color = 'white';
        item.style.textAlign = 'left';
        item.style.fontWeight = '300';
      });
    }
  
    // Clear div and add list
    divTopCarros.innerHTML = '';
    divTopCarros.appendChild(lista);
  }
  
  // Run on page load
  window.addEventListener('DOMContentLoaded', mostrarTop5Carros);
  
  // Update list after new sale (call this after form submission)
  document.getElementById('formularioVenda')?.addEventListener('submit', function () {
    // Wait briefly to ensure localStorage is updated
    setTimeout(mostrarTop5Carros, 0);
  });