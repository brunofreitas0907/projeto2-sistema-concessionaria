// Formatação de CPF
function formatarCPF(input) {
  let value = input.value.replace(/\D/g, "");
  if (value.length > 11) value = value.slice(0, 11);
  value = value
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
  input.value = value;
}

// Formatação de telefone
function formatarTelefone(input) {
  let value = input.value.replace(/\D/g, "");
  if (value.length > 11) value = value.slice(0, 11);
  value = value
    .replace(/(\d{2})(\d)/, "($1) $2")
    .replace(/(\d{5})(\d)/, "$1-$2");
  input.value = value;
}

// Formatação de CEP
function formatarCEP(input) {
  let value = input.value.replace(/\D/g, "");
  if (value.length > 8) value = value.slice(0, 8); // Limita a 8 dígitos
  value = value.replace(/(\d{5})(\d)/, "$1-$2");
  input.value = value;
}

// Validação do CPF
function validateCPF(cpf) {
  const regex = /^\d{3}\.\d{3}\.\d{3}-\d{2}$/;
  return regex.test(cpf);
}

// Validação do telefone
function validatePhone(telefone) {
  const regex = /^\(\d{2}\) \d{5}-\d{4}$/;
  return regex.test(telefone);
}

// Validação do email
function validateEmail(email) {
  const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return regex.test(email);
}

// Função para mostrar/esconder mensagens de erro
function showError(campoId, erroId, mostrar) {
  const campo = document.getElementById(campoId);
  const erro = document.getElementById(erroId);
  if (!campo || !erro) {
    console.error(
      `Erro: Elemento com ID ${campoId} ou ${erroId} não encontrado.`
    );
    return;
  }
  erro.style.display = mostrar ? "block" : "none";
  if (mostrar) {
    campo.classList.add("erro");
  } else {
    campo.classList.remove("erro");
  }
}

// Função para lidar com o envio do formulário de clientes
function handleSubmit(event) {
  event.preventDefault();
  let isValid = true;

  // Resetar os erros
  const campos = ["nome", "cpf-cadastro", "email", "telefone", "rua", "cidade"];
  campos.forEach((campo) =>
    showError(
      campo,
      `erro${
        campo.charAt(0).toUpperCase() +
        campo.slice(1).replace("-cadastro", "Cpf")
      }`,
      false
    )
  );

  // Validar campos
  const nome = document.getElementById("nome")?.value.trim();
  if (!nome) {
    showError("nome", "erroNome", true);
    isValid = false;
  }

  const cpf = document.getElementById("cpf-cadastro")?.value.trim();
  if (!cpf || !validateCPF(cpf)) {
    showError("cpf-cadastro", "erroCpf", true);
    isValid = false;
  }

  const email = document.getElementById("email")?.value.trim();
  if (!email || !validateEmail(email)) {
    showError("email", "erroEmail", true);
    isValid = false;
  }

  const telefone = document.getElementById("telefone")?.value.trim();
  if (!telefone || !validatePhone(telefone)) {
    showError("telefone", "erroTelefone", true);
    isValid = false;
  }

  const rua = document.getElementById("rua")?.value.trim();
  if (!rua) {
    showError("rua", "erroRua", true);
    isValid = false;
  }

  const cidade = document.getElementById("cidade")?.value.trim();
  if (!cidade) {
    showError("cidade", "erroCidade", true);
    isValid = false;
  }

  // Campos opcionais
  const numero = document.getElementById("numero")?.value.trim() || "";
  const estado = document.getElementById("estado")?.value.trim() || "";
  const cep = document.getElementById("cep")?.value.trim() || "";

  if (isValid) {
    // Cria o objeto cliente
    const cliente = {
      nome,
      cpf,
      email,
      telefone,
      rua,
      numero,
      cidade,
      estado,
      cep,
    };

    // Obtém a lista de clientes do localStorage ou inicializa um array vazio
    let clientesList = JSON.parse(localStorage.getItem("clientes")) || [];
    clientesList.push(cliente);

    try {
      // Salva no localStorage
      localStorage.setItem("clientes", JSON.stringify(clientesList));
      const mensagemSucesso = document.getElementById("mensagemSucesso");
      if (mensagemSucesso) {
        mensagemSucesso.style.display = "block";
        setTimeout(() => {
          mensagemSucesso.style.display = "none";
        }, 3000);
      }
      const formulario = document.getElementById("formularioCliente");
      if (formulario) formulario.reset();
      console.log("Dados do cliente:", cliente);
    } catch (e) {
      console.error("Erro ao salvar no LocalStorage:", e);
      alert(
        "Erro ao salvar os dados. Verifique se o armazenamento do navegador está habilitado."
      );
    }
  }
}

// Função para mostrar/esconder cadastro de clientes
document.addEventListener("DOMContentLoaded", () => {
  const botaoCadastrar = document.getElementById("cadastrarCliente");
  if (!botaoCadastrar) {
    console.error('Erro: Botão com ID "cadastrarCliente" não encontrado.');
    return;
  }
  botaoCadastrar.addEventListener("click", function (event) {
    event.preventDefault();
    const cadastro = document.getElementById("mostraCadastro");
    if (!cadastro) {
      console.error('Erro: Elemento com ID "mostraCadastro" não encontrado.');
      return;
    }
    console.log("Botão Cadastrar Cliente clicado. Alternando visibilidade.");
    cadastro.hidden = !cadastro.hidden;
  });

  // Adicionar formatação automática para CPF, telefone e CEP
  const cpfInput = document.getElementById("cpf-cadastro");
  if (cpfInput) cpfInput.addEventListener("input", () => formatarCPF(cpfInput));

  const telefoneInput = document.getElementById("telefone");
  if (telefoneInput)
    telefoneInput.addEventListener("input", () =>
      formatarTelefone(telefoneInput)
    );

  const cepInput = document.getElementById("cep");
  if (cepInput) cepInput.addEventListener("input", () => formatarCEP(cepInput));
});

// Função para pesquisar geral (clientes, veículos ou vendas)
function botaoPesquisaGeral() {
  const opcao = document.getElementById("opcao")?.value;
  const pesquisaGeral = document.getElementById("pesquisaGeral");
  const resultadoPesquisaGeral = document.getElementById(
    "resultadoPesquisaGeral"
  );

  if (!pesquisaGeral || !resultadoPesquisaGeral) {
    console.error(
      'Erro: Elemento com ID "pesquisaGeral" ou "resultadoPesquisaGeral" não encontrado.'
    );
    return;
  }

  if (!opcao) {
    resultadoPesquisaGeral.innerHTML =
      '<p class="no-results">Por favor, selecione uma opção.</p>';
    return;
  }

  if (opcao === "clientes") {
    let clientes = JSON.parse(localStorage.getItem("clientes")) || [];
    console.log("Clientes carregados do localStorage:", clientes);

    // Ocultar a aba de pesquisa
    pesquisaGeral.hidden = true;

    if (clientes.length === 0) {
      resultadoPesquisaGeral.innerHTML = `
                <p class="no-results">Nenhum cliente encontrado.</p>
                <button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
            `;
      return;
    }

    let tabela = `
            <table>
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>CPF</th>
                        <th>Email</th>
                        <th>Telefone</th>
                        <th>Rua</th>
                        <th>Número</th>
                        <th>Cidade</th>
                        <th>Estado</th>
                        <th>CEP</th>
                    </tr>
                </thead>
                <tbody>
        `;
    clientes.forEach((cliente) => {
      console.log("Exibindo cliente:", cliente);
      tabela += `
                <tr>
                    <td>${cliente.nome}</td>
                    <td>${cliente.cpf}</td>
                    <td>${cliente.email}</td>
                    <td>${cliente.telefone}</td>
                    <td>${cliente.rua}</td>
                    <td>${cliente.numero || "-"}</td>
                    <td>${cliente.cidade}</td>
                    <td>${cliente.estado || "-"}</td>
                    <td>${cliente.cep || "-"}</td>
                </tr>
            `;
    });
    tabela += `
                </tbody>
            </table>
            <button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
        `;
    resultadoPesquisaGeral.innerHTML = tabela;
  } else if (opcao === "veiculos") {
    let veiculos = JSON.parse(localStorage.getItem("veiculos")) || [];

    pesquisaGeral.hidden = true;

    if (veiculos.length === 0) {
      resultadoPesquisaGeral.innerHTML = `
                <p class="no-results">Nenhum veículo encontrado.</p>
                <button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
            `;
      return;
    }

    let tabela = `
        <table>
            <thead>
                <tr>
                    <th>Renavam</th>
                    <th>Placa</th>
                    <th>Marca</th>
                    <th>Cor</th>
                    <th>Ano</th>
                    <th>Modelo</th>
                    <th>Categoria</th>
                    <th>Combustível</th>
                    <th>Valor</th>
                </tr>
            </thead>
            <tbody>
    `;
    veiculos.forEach((veiculo) => {
      console.log("Exibindo veículo:", veiculo);
      tabela += `
            <tr>
                <td>${veiculo.renavam}</td>
                <td>${veiculo.placa}</td>
                <td>${veiculo.marcaModelo}</td>
                <td>${veiculo.cor}</td>
                <td>${veiculo.ano}</td>
                <td>${veiculo.modelo}</td>
                <td>${veiculo.categoria}</td>
                <td>${veiculo.combustivel}</td>
                <td>${formatarValor(veiculo.valor)}</td>
            </tr>
        `;
    });
    tabela += `
    </tbody>
</table>
<button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
`;
    resultadoPesquisaGeral.innerHTML = tabela;
  } else if (opcao === "vendas") {
    const vendas = JSON.parse(localStorage.getItem("vendas")) || [];

    pesquisaGeral.hidden = true;

    if (vendas.length === 0) {
      resultadoPesquisaGeral.innerHTML = `
                <p class="no-results">Nenhuma venda encontrada.</p>
                <button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
            `;
      return;
    }

    let tabela = `
            <table>
                <thead>
                    <tr>
                        <th>CPF</th>
                        <th>Renavam</th>
                        <th>Data</th>
                        <th>Forma de Pagamento</th>
                        <th>Valor</th>
                        
                    </tr>
                </thead>
                <tbody>
        `;

    tabela += vendas
      .map(
        (dado) => `
            <tr>
                <td>${dado.cpf}</td>
                <td>${dado.renavam}</td>
                <td>${dado.data}</td>
                <td>${dado.pagamento}</td>
                <td>R$ ${dado.valor}</td>
                
            </tr>
        `
      )
      .join("");

    tabela += `
                </tbody>
            </table>
            <button type="button" class="voltarPesquisa" onclick="voltarPesquisa()">Voltar</button>
        `;
    resultadoPesquisaGeral.innerHTML = tabela;
  }
}

// Função para voltar à aba de pesquisa
function voltarPesquisa() {
  const pesquisaGeral = document.getElementById("pesquisaGeral");
  const resultadoPesquisaGeral = document.getElementById(
    "resultadoPesquisaGeral"
  );

  if (!pesquisaGeral || !resultadoPesquisaGeral) {
    console.error(
      'Erro: Elemento com ID "pesquisaGeral" ou "resultadoPesquisaGeral" não encontrado.'
    );
    return;
  }

  console.log("Botão Voltar clicado. Restaurando aba de pesquisa.");
  pesquisaGeral.hidden = false;
  resultadoPesquisaGeral.innerHTML =
    '<button type="button" class="voltarPesquisa" onclick="voltarPesquisa()" style="display: none;">Voltar</button>';
}
